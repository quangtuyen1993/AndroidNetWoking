package com.example.androidnetwoking.model

data class ProductTypes (
    var _id:String
    , var _name:String
    , var _description:String)

